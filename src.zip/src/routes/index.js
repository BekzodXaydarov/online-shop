import React from "react";
import { Route, Routes } from "react-router-dom";
import Home from "../pages/home";
import Cart from "../pages/cart";
import Single from "../pages/product";
import User from "../pages/user";
import Buy from "../pages/buy";

export default function RootRouter({ data, book, setBook, addtocart,buy,setBuy }) {
  return (
    <Routes>
      <Route
        path="/"
        element={
          <Home
            data={data}
            setBook={setBook}
            book={book}
            addtocart={addtocart}
            buy={buy}
            setBuy={setBuy}

          />
        }
      />
      <Route path="/cart" element={<Cart book={book} setBook={setBook} />} />
      <Route path="/product/:id" element={<Single book={book} data={data} setBook={setBook} />}
      />
      {/* <Route path="/user" element={<User book={book} setBook={setBook} data={data} />} /> */}
      <Route path="/buy" element={<Buy  buy={buy} setBuy={setBuy} data={data} />} />
    </Routes>
  );
}
